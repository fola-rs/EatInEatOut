import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

const API = "http://localhost:5000/api";

export default function Pantry() {
  const [items, setItems] = useState(___);   // TODO: initial state — empty list or null?
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  async function fetchItems() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`${API}/___`);         // TODO: which endpoint?
      if (!res.ok) throw new Error("Failed to fetch pantry");
      setItems(await res.json());
    } catch (err) {
      setError(___);                                 // TODO: what do you set error to?
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { ___; }, []);                     // TODO: call fetchItems on load

  return (
    <div className="page">
      <h1 className="page-title">My Pantry</h1>

      {loading && <p>Loading…</p>}
      {error   && <p style={{ color: "red" }}>{error}</p>}

      {!loading && !error && items.length === 0 && (
        <p style={{ color: "#777" }}>No items in your pantry yet.</p>
      )}

      {!loading && !error && items.length > 0 && (
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Category</th>
              <th>Quantity</th>
              <th>Unit</th>
              <th>Expires</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => (
              <tr key={item.___}>             {/* TODO: unique key */}
                <td>{item.___}</td>           {/* TODO: name */}
                <td>{item.___}</td>           {/* TODO: category */}
                <td>{item.___}</td>           {/* TODO: quantity */}
                <td>{item.___}</td>           {/* TODO: unit */}
                <td>{item.___ ?? "—"}</td>    {/* TODO: expires_at, show dash if null */}
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <div style={{ marginTop: 24 }}>
        <Link to="/" className="btn btn-grey">Back to Main Menu</Link>
      </div>
    </div>
  );
}
